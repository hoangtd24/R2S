export const notificationSelector = state => state.notification

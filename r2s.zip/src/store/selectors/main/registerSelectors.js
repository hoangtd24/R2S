export const statusSelector = state => state.register.status
export const errorSelector = state => state.register.error
export const userSelector = state => state.register.user

export const authenticationSelector = state => state.authentication.status

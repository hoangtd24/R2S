import RegisterStep1 from './RegisterStep1/index'
import RegisterStep3 from './RegisterStep3/index'
export { RegisterStep1, RegisterStep3 }

import React from 'react'
import Home from '../Home'

const HR = props => {
  return <Home></Home>
}

HR.propTypes = {}

export default HR

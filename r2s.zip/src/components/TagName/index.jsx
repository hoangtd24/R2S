import './styles.scss'

const TagName = props => {
  return (
    <div className="tagName__container">
      <p>{props.title}</p>
    </div>
  )
}

export default TagName
